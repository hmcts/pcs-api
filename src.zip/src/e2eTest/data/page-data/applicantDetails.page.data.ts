export const applicantDetails = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  header : 'Please enter applicant\'s name',
  applicantFirstName: 'AutomationTestUser'
};
