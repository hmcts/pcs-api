export const provideMoreDetailsOfClaim = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Provide more details about your claim',
  continue: 'Continue'
}
