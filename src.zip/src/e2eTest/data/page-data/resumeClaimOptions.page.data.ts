export const resumeClaimOptions = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Resume Claim',
  resumeClaimOption: 'Do you want to resume your claim using your saved answers?',
  yes: 'Yes',
  no: 'No',
  continue: 'Continue'
}
