export const claimantCircumstances = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Claimant circumstances (placeholder)',
  continue: 'Continue'
}
