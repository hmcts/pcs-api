export const propertyIneligible = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Property not eligible for this online service'
}