export const dailyRentAmount = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Daily rent amount',
  basedOnPreviousAnswers: 'Based on your previous answers, the amount per day that unpaid rent should be charged at is: ',
  yes: 'Yes',
  no: 'No',
  enterAmountPerDayLabel: 'Enter amount per day that unpaid rent should be charged at'
}
