export const groundsForPossession = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Grounds for possession',
  groundsForPossessionSectionInlineText: 'Are you claiming possession because of rent arrears or breach of the tenancy (ground1)?',
  yes: 'Yes',
  no: 'No'
};
