export const reasonsForPossession = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Reasons for possession',
  detailsAboutYourReason: 'Reasons For possession Page Sample Text',
  breachOfTenancy: 'Breach of the tenancy (ground 1)'
};
