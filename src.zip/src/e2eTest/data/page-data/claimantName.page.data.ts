export const claimantName =
  {
    title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
    mainHeader: 'Claimant name',
    yes: 'Yes',
    no: 'No',
    whatIsCorrectClaimantName: 'What is the correct claimant name?',
    correctClaimantNameInput: 'Test claimant name'
  }
