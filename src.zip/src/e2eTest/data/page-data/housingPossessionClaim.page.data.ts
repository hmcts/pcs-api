export const housingPossessionClaim = {
    title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
    mainHeader: 'Make a housing possession claim online',
    continue: 'Continue',
    previous: 'Previous',
    cancel: 'Cancel'
};
