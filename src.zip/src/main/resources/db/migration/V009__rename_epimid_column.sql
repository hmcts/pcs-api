ALTER TABLE postcode_court_mapping
  RENAME COLUMN epimid TO epims_id;

