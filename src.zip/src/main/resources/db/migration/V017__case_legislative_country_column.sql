ALTER TABLE pcs_case
  ADD COLUMN legislative_country VARCHAR(20);
