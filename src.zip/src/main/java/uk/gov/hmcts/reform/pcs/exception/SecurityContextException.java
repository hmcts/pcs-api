package uk.gov.hmcts.reform.pcs.exception;

public class SecurityContextException extends RuntimeException {

    public SecurityContextException(String message) {
        super(message);
    }

}
