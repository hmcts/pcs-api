package uk.gov.hmcts.reform.pcs.exception;

public class IdamException extends RuntimeException {

    public IdamException(String message, Throwable cause) {
        super(message, cause);
    }

}
