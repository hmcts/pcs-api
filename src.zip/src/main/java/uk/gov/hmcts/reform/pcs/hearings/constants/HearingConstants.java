package uk.gov.hmcts.reform.pcs.hearings.constants;

public final class HearingConstants {

    public static final String HEARING_ENDPOINT = "/hearing";
    public static final String SERVICE_AUTHORIZATION = "ServiceAuthorization";

    private  HearingConstants() {
    }
}
