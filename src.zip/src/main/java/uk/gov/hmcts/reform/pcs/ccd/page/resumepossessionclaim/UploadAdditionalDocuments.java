package uk.gov.hmcts.reform.pcs.ccd.page.resumepossessionclaim;

import uk.gov.hmcts.reform.pcs.ccd.common.CcdPageConfiguration;
import uk.gov.hmcts.reform.pcs.ccd.common.PageBuilder;
import uk.gov.hmcts.reform.pcs.ccd.domain.PCSCase;

public class UploadAdditionalDocuments implements CcdPageConfiguration {

    @Override
    public void addTo(PageBuilder pageBuilder) {
        pageBuilder
            .page("uploadAdditionalDocuments")
            .pageLabel("Upload additional documents")
            .showCondition("wantToUploadDocuments=\"YES\"")
            
            // Horizontal line separator
            .label("uploadAdditionalDocuments-lineSeparator", "---")
            
            // Main heading
            .label("mainContent",
                """
                <h1 class="govuk-heading-l">Upload additional documents</h1>
                <p class="govuk-body govuk-!-font-size-19">
                  Select the type of document you want to upload and provide a description.
                </p>
                """
            )
            
            // Document type dropdown
            .mandatory(PCSCase::getAdditionalDocumentType)
            
            // Document upload field
            .label("documentUploadInfo",
                """
                <div class="govuk-form-group">
                  <h3 class="govuk-heading-m">Upload your document</h3>
                  <p class="govuk-body">
                    You can upload documents in PDF, DOC, DOCX, JPG, or PNG format.
                    Maximum file size: 10MB.
                  </p>
                </div>
                """
            )
            
            // Document upload field
            .optional(PCSCase::getUploadedDocument)
            
            // Document description field
            .optional(PCSCase::getDocumentDescription)
            
            // Navigation buttons
            .label("navigation",
                """
                <div class="govuk-button-group">
                  <button class="govuk-button" type="submit" name="action" value="continue">
                    Continue
                  </button>
                  <button class="govuk-button govuk-button--secondary" type="submit" name="action" value="previous">
                    Previous
                  </button>
                </div>
                <p class="govuk-body">
                  <a href="/cases" class="govuk-link">Cancel</a>
                </p>
                """
            );
    }
}