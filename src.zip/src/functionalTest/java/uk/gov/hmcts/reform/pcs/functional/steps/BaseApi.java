package uk.gov.hmcts.reform.pcs.functional.steps;

public class BaseApi {
    static {
        ApiSteps.setUp();
    }
}
