ALTER TABLE pcs_case
  DROP COLUMN payment_status;
