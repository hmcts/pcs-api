ALTER TABLE public.claim_ground
  ADD COLUMN ground_description VARCHAR(500)
