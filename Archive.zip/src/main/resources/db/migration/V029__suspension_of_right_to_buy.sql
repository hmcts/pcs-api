ALTER TABLE claim
  ADD COLUMN suspension_of_right_to_buy_housing_act VARCHAR(30),
  ADD COLUMN suspension_of_right_to_buy_reason VARCHAR(250);
