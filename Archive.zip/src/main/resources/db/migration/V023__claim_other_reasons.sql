ALTER TABLE claim
  ADD COLUMN additional_reasons VARCHAR(6400);
