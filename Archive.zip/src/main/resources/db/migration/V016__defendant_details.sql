ALTER TABLE pcs_case ADD COLUMN defendant_details JSONB;
