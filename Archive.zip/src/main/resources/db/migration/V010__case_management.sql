ALTER TABLE public.pcs_case
ADD COLUMN case_management_location INT,
ADD COLUMN payment_status VARCHAR(20);
