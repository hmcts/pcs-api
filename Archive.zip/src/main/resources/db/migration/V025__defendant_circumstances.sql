ALTER TABLE claim
  ADD COLUMN defendant_circumstances VARCHAR(950);
