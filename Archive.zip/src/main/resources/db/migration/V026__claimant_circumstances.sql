ALTER TABLE claim ADD COLUMN claimant_circumstances VARCHAR(950);
