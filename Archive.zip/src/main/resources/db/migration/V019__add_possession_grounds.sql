ALTER TABLE pcs_case ADD COLUMN possession_grounds JSONB;
