ALTER TABLE public.claim
ADD COLUMN costs_claimed BOOLEAN NOT NULL;
