ALTER TABLE claim ADD COLUMN application_with_claim BOOLEAN;

