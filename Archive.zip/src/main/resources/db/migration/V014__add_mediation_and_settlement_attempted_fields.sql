ALTER TABLE pcs_case ADD COLUMN mediation_attempted BOOLEAN;
ALTER TABLE pcs_case ADD COLUMN mediation_attempted_details TEXT;
ALTER TABLE pcs_case ADD COLUMN settlement_attempted BOOLEAN;
ALTER TABLE pcs_case ADD COLUMN settlement_attempted_details TEXT;