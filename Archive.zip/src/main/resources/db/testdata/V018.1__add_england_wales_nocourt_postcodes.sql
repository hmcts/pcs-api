INSERT INTO postcode_court_mapping (postcode, epims_id, legislative_country, effective_from, effective_to, audit)
VALUES ('SY45NN', 11111, 'England', '2025-08-29', NULL, '{"created_by": "admin", "change_reason": "initial insert"}');
INSERT INTO postcode_court_mapping (postcode, epims_id, legislative_country, effective_from, effective_to, audit)
VALUES ('SY45NN', 22222, 'Wales', '2025-08-29', NULL, '{"created_by": "admin", "change_reason": "initial insert"}');
