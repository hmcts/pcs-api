INSERT INTO eligibility_whitelisted_epim (epims_id, eligible_from, audit) VALUES
    (20262, '2025-07-14', '{"generated, R1, V1": "2025-07-08T10:02:39.968Z"}'::jsonb),
    (28837, '2025-07-14', '{"generated, R1, V1": "2025-07-08T10:02:39.968Z"}'::jsonb),
    (144641, '2025-07-14', '{"generated, R1, V1": "2025-07-08T10:02:39.968Z"}'::jsonb),
    (425094, '2025-07-14', '{"generated, R1, V1": "2025-07-08T10:02:39.968Z"}'::jsonb);
