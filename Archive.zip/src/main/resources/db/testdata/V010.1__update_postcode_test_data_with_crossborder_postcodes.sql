INSERT INTO postcode_court_mapping (postcode, epims_id, legislative_country, effective_from, effective_to, audit) VALUES
    ('SY132LH', 20262, 'England', '2025-06-01', NULL, '{"created_by": "admin", "change_reason": "initial insert"}'::jsonb),
    ('SY132LH', 28837, 'Wales', '2025-03-01', '2035-04-10', '{"created_by": "admin", "change_reason": "initial insert"}'::jsonb);


