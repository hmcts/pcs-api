package uk.gov.hmcts.reform.pcs.ccd.common;

public interface CcdPageConfiguration {

    void addTo(final PageBuilder pageBuilder);
}
