package uk.gov.hmcts.reform.pcs.ccd.accesscontrol;

enum RoleType {

    IDAM,
    RAS

}
