package uk.gov.hmcts.reform.pcs.postcodecourt.model;

public record Court(Integer id, String name, Integer epimId) {
}
