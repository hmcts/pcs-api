export const underlesseeOrMortgageeEntitledToClaim =
  {
    title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
    mainHeader: 'Underlessee or mortgagee entitled to claim relief against forfeiture (placeholder)',
    continue: 'Continue'
  };
