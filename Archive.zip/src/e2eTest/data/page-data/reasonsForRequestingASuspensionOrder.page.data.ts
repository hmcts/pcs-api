export const reasonsForRequestingASuspensionOrder = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Reasons for requesting a suspension order',
  question: 'Why are you requesting a suspension order?',
  sampleTestReason: 'This is the sample text for - Why are you requesting a suspension order?',
  continue: 'Continue'
};
