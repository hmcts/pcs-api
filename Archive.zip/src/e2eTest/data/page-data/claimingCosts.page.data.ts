export const claimingCosts =
  {
    title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
    mainHeader: 'Claiming costs',
    continue: 'Continue',
    yes: 'Yes',
    no: 'No'
  };