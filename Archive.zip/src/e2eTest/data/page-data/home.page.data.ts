export const home =
  {
    title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
    caseListTab: 'Case list',
    createCaseTab: 'Create case',
    findCaseTab: 'Find case'
  }
