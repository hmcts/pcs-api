export const checkYourAnswers = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  header: 'Check your answers',
  saveAndContinue: 'Save and continue'
};
