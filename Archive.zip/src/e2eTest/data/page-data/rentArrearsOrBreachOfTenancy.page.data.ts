export const rentArrearsOrBreachOfTenancy = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Rent arrears or breach of the tenancy (ground 1)',
  rentArrears: 'Rent arrears',
  breachOfTenancy: 'Breach of the tenancy',
  continue: 'Continue'
}
