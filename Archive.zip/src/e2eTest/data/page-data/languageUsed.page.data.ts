export const languageUsed = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Language used',
  no: 'No',
  continue: 'Continue',
};
