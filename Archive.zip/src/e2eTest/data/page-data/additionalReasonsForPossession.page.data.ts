export const additionalReasonsForPossession = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Additional reasons for possession',
  yes: 'Yes',
  no: 'No',
  additionalReasonsForPossessionLabel: 'Additional reasons for possession',
  additionalReasonsForPossessionSampleText: 'This is the sample text for - Is there any other information you’d like to provide about your reasons for possession',
  continue: 'Continue'
};
