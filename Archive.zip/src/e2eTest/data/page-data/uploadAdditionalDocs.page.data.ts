export const uploadAdditionalDocs = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Upload additional documents',
  continue: 'Continue',
  typeOfDocument: 'Type of document',
  shortDescriptionLabel: 'Short Description',
  tenancyAgreementOption: 'Tenancy Agreement',
  shortDescriptionInput: 'This is a tenancy agreement'
}
