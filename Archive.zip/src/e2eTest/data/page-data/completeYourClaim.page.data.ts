export const completeYourClaim = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Completing your claim (placeholder)',
  continue: 'Continue',
  submitAndClaimNow: 'Submit and pay for my claim now',
  saveItForLater: 'Save it for later'
}
