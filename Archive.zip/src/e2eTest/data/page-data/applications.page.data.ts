export const applications = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Applications',
  continue: 'Continue',
  yes: 'Yes',
  no: 'No'
}
