export const statementOfTruth = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Statement of truth',
  continue: 'Continue'
}
