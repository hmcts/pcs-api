export const propertyDetails = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  buildingAndStreetLabel: 'Building and Street',
  addressLine2Label: 'Address Line 2',
  townOrCityLabel: 'Town or City',
  postcodeZipcodeLabel: 'Postcode/Zipcode',
  countryLabel: 'Country'
};
