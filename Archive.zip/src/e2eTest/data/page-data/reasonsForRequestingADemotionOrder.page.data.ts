export const reasonsForRequestingADemotionOrder = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Reasons for requesting a demotion order',
  requestDemotionOrderQuestion: 'Why are you requesting a demotion order?',
  sampleTestReason: 'This is the sample text for - Why are you requesting a demotion order?',
  continue: 'Continue'
};
