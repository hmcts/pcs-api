export const claimantCircumstances = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'Claimant circumstances',
  claimantCircumstanceInfo: 'Is there any information you\'d like to provide about Claimants circumstances?',
  yes: 'Yes',
  no: 'No',
  continue: 'Continue',
  claimantCircumstanceInfoTextAreaLabel: 'Give details about Claimants circumstances',
  claimantCircumstanceInfoInputData: 'Sample Claimant circumstances input data',
};