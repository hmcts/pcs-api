export const userIneligible = {
  title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
  mainHeader: 'You\'re not eligible for this online service',
  eventNotCreated: 'The event could not be created',
  unableToProceed: 'Unable to proceed because there are one or more callback Errors or Warnings',
  errors: 'Errors',
  notEligibleForOnlineService: 'You\'re not eligible for this online service',
  continue: 'Continue',
  cancel: 'Cancel'
}
