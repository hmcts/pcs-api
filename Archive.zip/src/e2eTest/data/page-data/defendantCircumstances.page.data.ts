export const defendantCircumstances =
  {
    title: 'Create a case - HM Courts & Tribunals Service - GOV.UK',
    mainHeader: 'Defendants\' circumstances',
    defendantCircumstancesInfo: 'Is there any information you\'d like to provide about defendants\' circumstances?',
    yes: 'Yes',
    no: 'No',
    defendantCircumstancesLabel: 'Give details about the defendants\' circumstances',
    defendantCircumstancesSampleData: 'Defendant circumstances sample test input data',
    continue: 'Continue',
  }
