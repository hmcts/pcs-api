# App infrastructure

Add any application specific infrastructure to the terraform files in this folder

This could be things like:
* a database
* redis
* vault
* application insights

If you don't need any application infrastructure here, you can delete the whole folder (it will speed up your Jenkins build)
